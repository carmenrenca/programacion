package IE11;

public class ejercicio4 {

	public static void main(String[] args) {
		String  cont;
		int contador;
		
		cont="*";
		contador=0;
	
		while (contador<5){
			
			contador++;
			
			System.out.println(cont);
			cont=cont+"*";
					
		}
		
	
	}

}
